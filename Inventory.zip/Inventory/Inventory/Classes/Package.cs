﻿namespace Inventory
{
    class Package
    {
        public Package(string deliveryNumber, string height, string length, string weight, string width, string returnNumber, string deliveryAddress1, string deliveryAddress2, string deliveryCity, string deliveryCountry, string deliveryName, string deliveryPostcode, string deliverySurname, string returnAddress1, string returnAddress2, string returnCity, string returnCountry, string returnName, string returnPostcode, string returnSurname, string packageNumber)
        {
            this.deliverynumber = deliveryNumber;
            this.height = height;
            this.length = length;
            this.weight = weight;
            this.width = width;
            this.returnnumber = returnNumber;
            this.deliveryaddress1 = deliveryAddress1;
            this.deliveryaddress2 = deliveryAddress2;
            this.deliverycity = deliveryCity;
            this.deliverycountry = deliveryCountry;
            this.deliveryname = deliveryName;
            this.deliverypostcode = deliveryPostcode;
            this.deliverysurname = deliverySurname;
            this.returnaddress1 = returnAddress1;
            this.returnaddress2 = returnAddress2;
            this.returncity = returnCity;
            this.returncountry = returnCountry;
            this.returnname = returnName;
            this.returnpostcode = returnPostcode;
            this.returnsurname = returnSurname;
            this.packagenumber = packageNumber;
        }



        public string deliverynumber { get; set; }
        public string height { get; set; }
        public string length { get; set; }
        public string weight { get; set; }
        public string width { get; set; }
        public string returnnumber { get; set; }
        public string deliveryaddress1 { get; set; }
        public string deliveryaddress2 { get; set; }
        public string deliverycity { get; set; }
        public string deliverycountry { get; set; }
        public string deliveryname { get; set; }
        public string deliverypostcode{ get; set; }
        public string deliverysurname { get; set; }
        public string returnaddress1 { get; set; }
        public string returnaddress2 { get; set; }
        public string returncity { get; set; }
        public string returncountry { get; set; }
        public string returnname { get; set; }
        public string returnpostcode { get; set; }
        public string returnsurname { get; set; }
        public string packagenumber{ get; set; }
    }
}
