﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Add_Package : Form
    {
        public Add_Package()
        {
            InitializeComponent();
        }

        private void delivery_Click(object sender, EventArgs e)
        {

        }

        private void Add_Package_load(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            //check if textboxes are empty
            foreach (Control c in this.package.Controls)
            {
                if (c is TextBox)
                {
                    if (c.Text.Equals(""))
                    {
                        MessageBox.Show("Please enter missing fields!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        c.Focus();
                        return;
                    }
                }
                    
            }

            /*
            //check if integer textboxes contains integers
            int Value;
            if (!int.TryParse(txtweight.Text, out Value))
            {
                MessageBox.Show("Please enter a number");
                txtweight.Focus();
                return;
            }
            else if(!int.TryParse(txtheight.Text, out Value))
            {
                MessageBox.Show("Please enter a number");
                txtheight.Focus();
                return;
            }
            else if(!int.TryParse(txtlength.Text, out Value))
            {
                MessageBox.Show("Please enter a number");
                txtlength.Focus();
                return;
            }

            else if (!int.TryParse(txtwidth.Text, out Value))
            {
                MessageBox.Show("Please enter a number");
                txtwidth.Focus();
                return;
            }*/




            try
            {
                db sqlCon = new db();
                //if successfully added
                if (sqlCon.insertpack(txttelephone.Text, txtheight.Text, txtlength.Text, txtweight.Text, txtwidth.Text, txttelephone_2.Text, txtaddress1_2.Text, txtaddress2_2.Text, txtcity_2.Text,  txtcountry_2.Text, txtname_2.Text, txtpostcode_2.Text, txtsurname_2.Text, txtaddress1.Text, txtaddress2.Text, txtcity.Text, txtcountry.Text, txtname.Text, txtpostcode.Text, txtsurname.Text, txtpackagenumber.Text))
                {
                    MessageBox.Show("Successfully added an employee!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    //switching to search after completion
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Username already exists!\nPlease chooe a different one.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        //moving through the tabs
        private void btnnext_Click(object sender, EventArgs e)
        {
            TabControl1.SelectTab(1);
        }

        private void btnprevious_Click(object sender, EventArgs e)
        {
            TabControl1.SelectTab(0);
        }

        private void btnnext_2_Click(object sender, EventArgs e)
        {
            TabControl1.SelectTab(2);
        }

        private void btnprevious2_Click(object sender, EventArgs e)
        {
            TabControl1.SelectTab(1);
        }


        //go back to main menu when cancle button is pressed
        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenu mm = new MainMenu();
            mm.Show();
        }
    }
}
